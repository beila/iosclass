//
//  View2ViewController.h
//  View2
//
//  Created by ioacademy on 13. 3. 2..
//  Copyright (c) 2013년 ioacademy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View2ViewController : UIViewController

@end
