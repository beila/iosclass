//
//  ViewController.h
//  AnimationSample
//
//  Created by ioacademy on 13. 3. 2..
//  Copyright (c) 2013년 ioacademy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
@property (retain, nonatomic) IBOutlet UILabel *lavel1;
@property (retain, nonatomic) IBOutlet UILabel *label2;
- (IBAction)click1:(id)sender;
- (IBAction)click2:(id)sender;
- (IBAction)click3:(id)sender;
@property (retain, nonatomic) IBOutlet UILabel *label1;

@end
