//
//  UIColor+RandomColor.h
//  RandomColor
//
//  Created by chansigi on 3/4/15.
//  Copyright (c) 2015 IOACADEMY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (RandomColor)
+ (UIColor*)randomColor;
@end
