//
//  NaviModel1Tests.h
//  NaviModel1Tests
//
//  Created by ioacademy on 13. 3. 2..
//  Copyright (c) 2013년 ioacademy. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface NaviModel1Tests : SenTestCase

@end
