//
//  UIApplicationTests.h
//  UIApplicationTests
//
//  Created by ioacademy on 13. 3. 9..
//  Copyright (c) 2013년 ioacademy. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface UIApplicationTests : SenTestCase

@end
