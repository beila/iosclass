//
//  MultiView2Tests.h
//  MultiView2Tests
//
//  Created by ioacademy on 13. 3. 2..
//  Copyright (c) 2013년 ioacademy. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface MultiView2Tests : SenTestCase

@end
