//
//  View3Tests.h
//  View3Tests
//
//  Created by ioacademy on 13. 3. 2..
//  Copyright (c) 2013년 ioacademy. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface View3Tests : SenTestCase

@end
