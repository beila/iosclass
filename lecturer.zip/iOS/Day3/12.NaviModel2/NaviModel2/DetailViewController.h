//
//  DetailViewController.h
//  NaviModel2
//
//  Created by chansigi on 3/11/15.
//  Copyright (c) 2015 IOACADEMY. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DetailViewController : UIViewController

@property (strong, nonatomic) id detailItem;

@end
