//
//  MasterViewController.h
//  NaviModel2
//
//  Created by chansigi on 3/11/15.
//  Copyright (c) 2015 IOACADEMY. All rights reserved.
//

#import <UIKit/UIKit.h>

@class DetailViewController;
@interface MasterViewController : UITableViewController

@property (strong, nonatomic) DetailViewController *detailViewController;

@end
