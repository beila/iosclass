//
//  프라퍼티.h
//  Objective-C정리
//
//  Created by imguru on 13. 2. 23..
//  Copyright (c) 2013년 imguru. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ________ : NSObject

@end
