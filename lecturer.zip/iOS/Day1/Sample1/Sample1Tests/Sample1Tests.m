//
//  Sample1Tests.m
//  Sample1Tests
//
//  Created by imguru on 13. 2. 23..
//  Copyright (c) 2013년 imguru. All rights reserved.
//

#import "Sample1Tests.h"

@implementation Sample1Tests

- (void)setUp
{
    [super setUp];
    
    // Set-up code here.
}

- (void)tearDown
{
    // Tear-down code here.
    
    [super tearDown];
}

- (void)testExample
{
    STFail(@"Unit tests are not implemented yet in Sample1Tests");
}

@end
