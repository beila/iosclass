//
//  Sample1Tests.h
//  Sample1Tests
//
//  Created by imguru on 13. 2. 23..
//  Copyright (c) 2013년 imguru. All rights reserved.
//

#import <SenTestingKit/SenTestingKit.h>

@interface Sample1Tests : SenTestCase

@end
