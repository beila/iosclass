//
//  AppDelegate.h
//  Sample1
//
//  Created by imguru on 13. 2. 23..
//  Copyright (c) 2013년 imguru. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate, UIActionSheetDelegate  >

@property (strong, nonatomic) UIWindow *window;

@end
