//
//  ViewController.h
//  Gesture
//
//  Created by ioacademy on 13. 3. 9..
//  Copyright (c) 2013년 ioacademy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    float rot;
    float scale;
}
@property (retain, nonatomic) IBOutlet UIImageView *imgView;

@end
