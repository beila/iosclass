#import <UIKit/UIKit.h>

@interface MyNavigationBar : UINavigationBar

@property(nonatomic, strong) UIImageView* imgView;

@end